from django.contrib import admin
from .models import Mall

# Register your models here.
admin.site.register(Mall)